import maniac

from keep_alive import keep_alive

if __name__ == "__main__":
    keep_alive()
    maniac.run_bot()